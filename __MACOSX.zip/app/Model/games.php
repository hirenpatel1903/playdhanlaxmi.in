<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class games extends Model
{
     protected $table = 'games';
}
