<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
    .blinking {
	text-align:center;
    background: red;
	border-radius: 70px;
}

.blinking.blink {
	opacity:0;
}
</style>
	<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
          <!--breadcrumb-->
          <div class="md-col-12">
            <span class="dcoder"></span>
          </div>
					<div class="row">
                        <?php
                        $i = 1;
                        $j = 1;
                        ?>
                        <?php if($games->count()> 0): ?>
                         <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-12 col-lg-3">
                                    <div class="card radius-15">
                                        <div class="card-body">
                                            <div class="d-flex align-items-center">
                                                <div>
                                                    <h2 class="mb-0 text-white">Amount:<span><?= $sumamou = DB::table('dalygame')->where('status',0)->where('game',$item->name)->sum('amount'); ?> </span></h2>
                                                </div>
                                            </div>
                                            <div class="d-flex align-items-center">
                                                <div>
                                                    <p class="mb-0 text-white">name: <?= strtoupper($item->name ?? '') ?></p>
                                                    <p class="mb-0 text-white">Date: <?php
                                                       date_default_timezone_set('Asia/Kolkata');
                                                        echo date("Y-m-d");
                                                        ?>
                                                        </p>
                                                <?php if(empty(Session::get('mynumber1'))): ?>
                                                    <?php
                                                    session()->forget('mynumber1');
                                                    $digits = 2;
                                                    $uniq = rand(pow(10, $digits-1), pow(10, $digits)-1);
                                                    Session::put('mynumber'.$j,$item->name.$uniq);
                                                    ?>
                                                <?php elseif(empty(Session::get('mynumber2'))): ?>
                                                <?php
                                                    session()->forget('mynumber2');
                                                    $digits = 2;
                                                    $uniq = rand(pow(10, $digits-1), pow(10, $digits)-1);
                                                    Session::put('mynumber'.$j,$item->name.$uniq);
                                                    ?>
                                                <?php elseif(empty(Session::get('mynumber3'))): ?>
                                                <?php
                                                   session()->forget('mynumber3');
                                                    $digits = 2;
                                                    $uniq = rand(pow(10, $digits-1), pow(10, $digits)-1);
                                                    Session::put('mynumber'.$j,$item->name.$uniq);
                                                    ?>
                                                <?php elseif(empty(Session::get('mynumber4'))): ?>
                                                <?php
                                                   session()->forget('mynumber4');
                                                    $digits = 2;
                                                    $uniq = rand(pow(10, $digits-1), pow(10, $digits)-1);
                                                    Session::put('mynumber'.$j,$item->name.$uniq);
                                                    ?>
                                                <?php endif; ?>
                                                    <p style="display:none;" class="shownumber">This Number Is Open: <strong><?php echo e(strtoupper(Session::get('mynumber'.$j))); ?></strong></p>
                                                    <p style="display:none;" class="mb-0 text-white shownumber"><button data-toggle="modal" data-target="#myModal<?php echo e($i++); ?>" class="btn btn-danger btn-sm">Edit</button></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php $j++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

					</div>
					<!--end breadcrumb-->
				</div>
			</div>
			<!--end page-content-wrapper-->
        </div>
		<?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>


<div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
        <form action="<?php echo e(url('admin/changenumber')); ?>" method="Post">
            <?php echo csrf_field(); ?>
            <div class="form-group" >
                <select class="form-control" name="game" required>
                <option value="">Select Option</option>
                    <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($gameitem->name ?? ''); ?>"><?php echo e($gameitem->name ?? ''); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
           <div class="form-group">
               <input type="text" class="form-control" name="number">
           </div>

           <input type="submit" name="submit" value="Submit" class="btn btn-success">
        </form>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
        <form action="<?php echo e(url('admin/changenumber1')); ?>" method="Post">
            <?php echo csrf_field(); ?>
            <div class="form-group" >
                <select class="form-control" name="game" required>
                <option value="">Select Option</option>
                    <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($gameitem->name ?? ''); ?>"><?php echo e($gameitem->name ?? ''); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
           <div class="form-group">
               <input type="text" class="form-control" name="number">
           </div>

           <input type="submit" name="submit" value="Submit" class="btn btn-success">
        </form>
        </div>
      </div>
    </div>
  </div>
  <div class="modal fade" id="myModal3" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
        <form action="<?php echo e(url('admin/changenumber2')); ?>" method="Post">
            <?php echo csrf_field(); ?>
            <div class="form-group" >
                <select class="form-control" name="game" required>
                <option value="">Select Option</option>
                    <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($gameitem->name ?? ''); ?>"><?php echo e($gameitem->name ?? ''); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
           <div class="form-group">
               <input type="text" class="form-control" name="number">
           </div>

           <input type="submit" name="submit" value="Submit" class="btn btn-success">
        </form>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="myModal4" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
        <form action="<?php echo e(url('admin/changenumber3')); ?>" method="Post">
            <?php echo csrf_field(); ?>
            <div class="form-group" >
                <select class="form-control" name="game" required>
                <option value="">Select Option</option>
                    <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($gameitem->name ?? ''); ?>"><?php echo e($gameitem->name ?? ''); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
           <div class="form-group">
               <input type="text" class="form-control" name="number">
           </div>

           <input type="submit" name="submit" value="Submit" class="btn btn-success">
        </form>
        </div>
      </div>
    </div>
  </div>


<?php
  $timeslot = DB::table('timeslote')->get();
  $starttime = strtotime("-5 minutes", strtotime($timeslot[1]->times));
  $h = date('h', $starttime);
  $m = date('i', $starttime);
  $hov = strtotime($timeslot[1]->times);
  $hover = date('h', $hov);
  $min = date('i', $hov);


  $starttime1 = strtotime("-5 minutes", strtotime($timeslot[2]->times));
  $h1 = date('h', $starttime1);
  $m1 = date('i', $starttime1);

  $hov1 = strtotime($timeslot[1]->times);
  $hover1 = date('h', $hov1);
  $min1 = date('i', $hov1);


  $starttime2 = strtotime("-5 minutes", strtotime($timeslot[3]->times));
  $h2 = date('h', $starttime2);
  $m2 = date('i', $starttime2);

  $hov2 = strtotime($timeslot[3]->times);
  $hover2 = date('h', $hov2);
  $min2 = date('i', $hov2);

  $starttime3 = strtotime("-5 minutes", strtotime($timeslot[4]->times));
  $h3 = date('h', $starttime3);
  $m3 = date('i', $starttime3);

  $hov3 = strtotime($timeslot[4]->times);
  $hover3 = date('h', $hov3);
  $min3 = date('i', $hov3);

  $starttime4 = strtotime("-5 minutes", strtotime($timeslot[5]->times));
  $h4 = date('h', $starttime4);
  $m4 = date('i', $starttime4);

  $hov4 = strtotime($timeslot[5]->times);
  $hover4 = date('h', $hov4);
  $min4 = date('i', $hov4);

  $starttime5 = strtotime("-5 minutes", strtotime($timeslot[6]->times));
  $h5 = date('h', $starttime5);
  $m5 = date('i', $starttime5);

  $hov5 = strtotime($timeslot[6]->times);
  $hover5 = date('h', $hov5);
  $min5 = date('i', $hov5);

  $starttime6 = strtotime("-5 minutes", strtotime($timeslot[7]->times));

  $h6 = date('h', $starttime6);
  $m6 = date('i', $starttime6);

  $hov6 = strtotime($timeslot[7]->times);
  $hover6 = date('h', $hov6);
  $min6 = date('i', $hov6);

  $starttime7 = strtotime("-5 minutes", strtotime($timeslot[8]->times));

  $h7 = date('h', $starttime7);
  $m7 = date('i', $starttime7);

  $hov7 = strtotime($timeslot[8]->times);
  $hover7 = date('h', $hov7);
  $min7 = date('i', $hov7);

  $starttime8 = strtotime("-5 minutes", strtotime($timeslot[9]->times));

  $h8 = date('h', $starttime8);
  $m8 = date('i', $starttime8);

  $hov8 = strtotime($timeslot[9]->times);
  $hover8 = date('h', $hov8);
  $min8 = date('i', $hov8);

  $starttime9 = strtotime("-5 minutes", strtotime($timeslot[10]->times));
  $h9 = date('h', $starttime9);
  $m9 = date('i', $starttime9);

  $hov9 = strtotime($timeslot[10]->times);
  $hover9 = date('h', $hov9);
  $min9 = date('i', $hov9);

  $starttime10 = strtotime("-5 minutes", strtotime($timeslot[11]->times));
  $h10 = date('h', $starttime10);
  $m10 = date('i', $starttime10);

  $hov10 = strtotime($timeslot[11]->times);
  $hover10 = date('h', $hov10);
  $min10 = date('i', $hov10);

  $starttime11 = strtotime("-5 minutes", strtotime($timeslot[12]->times));
  $h11 = date('h', $starttime11);
  $m11 = date('i', $starttime11);

  $hov11 = strtotime($timeslot[12]->times);
  $hover11 = date('h', $hov11);
  $min11 = date('i', $hov11);

  $starttime12 = strtotime("-5 minutes", strtotime($timeslot[13]->times));

  $h12 = date('h', $starttime12);
  $m12 = date('i', $starttime12);

  $hov12 = strtotime($timeslot[13]->times);
  $hover12 = date('h', $hov12);
  $min12 = date('i', $hov12);

  $starttime13 = strtotime("-5 minutes", strtotime($timeslot[14]->times));
  $h13 = date('h', $starttime13);
  $m13 = date('i', $starttime13);

  $hov13 = strtotime($timeslot[14]->times);
  $hover13 = date('h', $hov13);
  $min13 = date('i', $hov13);

  $starttime14 = strtotime("-5 minutes", strtotime($timeslot[15]->times));

  $h14 = date('h', $starttime14);
  $m14 = date('i', $starttime14);

  $hov14 = strtotime($timeslot[15]->times);
  $hover14 = date('h', $hov14);
  $min14 = date('i', $hov14);

  $starttime15 = strtotime("-5 minutes", strtotime($timeslot[16]->times));
  $starttimes15 = date('h:i', $starttime15);
  $h15 = date('h', $starttime15);
  $m15 = date('i', $starttime15);

  $hov15 = strtotime($timeslot[16]->times);
  $hover15 = date('h', $hov15);
  $min15 = date('i', $hov15);

  $starttime16 = strtotime("-5 minutes", strtotime($timeslot[17]->times));

  $h16 = date('h', $starttime16);
  $m16 = date('i', $starttime16);

  $hov16 = strtotime($timeslot[17]->times);
  $hover16 = date('h', $hov16);
  $min16 = date('i', $hov16);

  $starttime17 = strtotime("-5 minutes", strtotime($timeslot[18]->times));
  $h17 = date('h', $starttime17);
  $m17 = date('i', $starttime17);

  $hov17 = strtotime($timeslot[18]->times);
  $hover17 = date('h', $hov17);
  $min17 = date('i', $hov17);

  $starttime18 = strtotime("-5 minutes", strtotime($timeslot[19]->times));
  $h18 = date('h', $starttime18);
  $m18 = date('i', $starttime18);

  $hov18 = strtotime($timeslot[19]->times);
  $hover18 = date('h', $hov18);
  $min18 = date('i', $hov18);

  $starttime19 = strtotime("-5 minutes", strtotime($timeslot[20]->times));

  $h19 = date('h', $starttime19);
  $m19 = date('i', $starttime19);

  $hov19 = strtotime($timeslot[20]->times);
  $hover19 = date('h', $hov19);
  $min19 = date('i', $hov19);


  $starttime20 = strtotime("-5 minutes", strtotime($timeslot[21]->times));
  $h20 = date('h', $starttime20);
  $m20 = date('i', $starttime20);

  $hov20 = strtotime($timeslot[21]->times);
  $hover20 = date('h', $hov20);
  $min20 = date('i', $hov20);

  $starttime21 = strtotime("-5 minutes", strtotime($timeslot[22]->times));

  $h21 = date('h', $starttime21);
  $m21 = date('i', $starttime21);

  $hov21 = strtotime($timeslot[22]->times);
  $hover21 = date('h', $hov21);
  $min21 = date('i', $hov21);

  $starttime22 = strtotime("-5 minutes", strtotime($timeslot[23]->times));
  $h22 = date('h', $starttime22);
  $m22 = date('i', $starttime22);

  $hov22 = strtotime($timeslot[23]->times);
  $hover22 = date('h', $hov22);
  $min22 = date('i', $hov22);

  $starttime23 = strtotime("-5 minutes", strtotime($timeslot[24]->times));
  $h23 = date('h', $starttime23);
  $m23 = date('i', $starttime23);

  $hov23 = strtotime($timeslot[24]->times);
  $hover23 = date('h', $hov23);
  $min23 = date('i', $hov23);

 ?>

<script>

var hov1 = "<?php echo e($hover); ?>";
var min1 = "<?php echo e($min); ?>";
    var hs1= "<?php echo e($h); ?>";
    var ms1= "<?php echo e($m); ?>";



var hov2 = "<?php echo e($hover1); ?>";
var min2 = "<?php echo e($min1); ?>";
    var hs2 = "<?php echo e($h2); ?>";
    var ms2 = "<?php echo e($m2); ?>";


var hov3 = "<?php echo e($hover2); ?>";
var min3 = "<?php echo e($min2); ?>";
    var hs3 = "<?php echo e($h3); ?>";
    var ms3 = "<?php echo e($m3); ?>";

var hov4 = "<?php echo e($hover3); ?>";
var min4 = "<?php echo e($min3); ?>";
    var hs4 = "<?php echo e($h4); ?>";
    var ms4 = "<?php echo e($m4); ?>";

var hov5 = "<?php echo e($hover4); ?>";
var min5 = "<?php echo e($min4); ?>";
    var hs5 = "<?php echo e($h5); ?>";
    var ms5 = "<?php echo e($m5); ?>";

var hov6 = "<?php echo e($hover5); ?>";
var min6 = "<?php echo e($min5); ?>";
    var hs6 = "<?php echo e($h6); ?>";
    var ms6 = "<?php echo e($m6); ?>";

var hov7 = "<?php echo e($hover6); ?>";
var min7 = "<?php echo e($min6); ?>";
    var hs7 = "<?php echo e($h7); ?>";
    var ms7 = "<?php echo e($m7); ?>";

var hov8 = "<?php echo e($hover7); ?>";
var min8 = "<?php echo e($min7); ?>";
    var hs8 = "<?php echo e($h8); ?>";
    var ms8 = "<?php echo e($m8); ?>";

var hov9 = "<?php echo e($hover8); ?>";
var min9 = "<?php echo e($min8); ?>";
    var hs9 = "<?php echo e($h9); ?>";
    var ms9 = "<?php echo e($m9); ?>";

var hov10 = "<?php echo e($hover9); ?>";
var min10 = "<?php echo e($min9); ?>";
    var hs10 = "<?php echo e($h10); ?>";
    var ms10 = "<?php echo e($m10); ?>";

var hov11 = "<?php echo e($hover10); ?>";
var min11 = "<?php echo e($min10); ?>";
    var hs11 = "<?php echo e($h11); ?>";
    var ms11 = "<?php echo e($m11); ?>";


var hov12 = "<?php echo e($hover11); ?>";
var min12 = "<?php echo e($min11); ?>";
    var hs12 = "<?php echo e($h12); ?>";
    var ms12 = "<?php echo e($m12); ?>";

var hov13 = "<?php echo e($hover12); ?>";
var min13 = "<?php echo e($min12); ?>";
    var hs13 = "<?php echo e($h13); ?>";
    var ms13 = "<?php echo e($m13); ?>";

var hov14 = "<?php echo e($hover13); ?>";
var min14 = "<?php echo e($min13); ?>";
    var hs14 = "<?php echo e($h14); ?>";
    var ms14 = "<?php echo e($m14); ?>";

var hov15 = "<?php echo e($hover14); ?>";
var min15 = "<?php echo e($min14); ?>";
    var hs15 = "<?php echo e($h15); ?>";
    var ms15 = "<?php echo e($m15); ?>";

var hov16 = "<?php echo e($hover15); ?>";
var min16 = "<?php echo e($min15); ?>";
    var hs16 = "<?php echo e($h16); ?>";
    var ms16 = "<?php echo e($m16); ?>";

var hov17 = "<?php echo e($hover16); ?>";
var min17 = "<?php echo e($min16); ?>";
    var hs17 = "<?php echo e($h17); ?>";
    var ms17 = "<?php echo e($m17); ?>";


var hov18 = "<?php echo e($hover17); ?>";
var min18 = "<?php echo e($min17); ?>";
    var hs18 = "<?php echo e($h18); ?>";
    var ms18 = "<?php echo e($m18); ?>";


var hov19 = "<?php echo e($hover18); ?>";
var min19 = "<?php echo e($min18); ?>";
    var hs19 = "<?php echo e($h19); ?>";
    var ms19 = "<?php echo e($m19); ?>";

var hov20 = "<?php echo e($hover19); ?>";
var min20 = "<?php echo e($min19); ?>";
    var hs20 = "<?php echo e($h20); ?>";
    var ms20 = "<?php echo e($m20); ?>";


var hov21 = "<?php echo e($hover20); ?>";
var min21 = "<?php echo e($min20); ?>";
    var hs21 = "<?php echo e($h21); ?>";
    var ms21 = "<?php echo e($m21); ?>";

var hov22 = "<?php echo e($hover21); ?>";
var min22 = "<?php echo e($min21); ?>";
    var hs22 = "<?php echo e($h22); ?>";
    var ms22 = "<?php echo e($m22); ?>";

var hov23 = "<?php echo e($hover22); ?>";
var min23 = "<?php echo e($min22); ?>";
    var hs23 = "<?php echo e($h23); ?>";
    var ms23 = "<?php echo e($m23); ?>";




var addnumber = "<?php echo e(url('admin/addnumber')); ?>";
$(function(){
	var $blinkText = $(".blinking");
	setInterval(function() {
		$blinkText.toggleClass("blink");
	}, 1000);
});

function refresh(){
    var now = new Date();
    var h = now.getHours() % 12 || 12;
    var m = now.getMinutes();
    var s = now.getSeconds();
    var mli = now.getMilliseconds();
    var out = h+" : "+m+" : "+s;
    var datetime = h+":"+m;
    // alert(datetime);
    var trig = setTimeout(refresh,500);

    document.getElementsByClassName("dcoder")[0].innerHTML = out;

    if(hs1==h && ms1==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }
    if(hs2==h && ms2==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }
    if(hs3==h && ms3==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }
    if(hs4==h && ms4==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }
    if(hs5==h && ms5==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }
    if(hs6==h && ms6==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }
    if(hs7==h && ms7==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }
    if(hs8==h && ms8==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }
    if(hs9==h && ms9==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }
    if(hs10==h && ms10==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }
    if(hs11==h && ms11==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }
    if(hs12==h && ms12==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }
    if(hs13==h && ms13==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }
    if(hs14==h && ms14==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }
    if(hs15==h && ms15==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }
    if(hs16==h && ms16==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }if(hs17==h && ms17==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }
    if(hs18==h && ms18==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }if(hs19==h && ms19==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }if(hs20==h && ms20==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }if(hs21==h && ms21==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }if(hs22==h && ms22==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }if(hs23==h && ms23==m){
        $(".shownumber").show();
        if(s==1){
             window.location.reload();
        }
    }

    if(h==hov1 && min1==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov2 && min2==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov3 && min3==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov4 && min4==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov5 && min5==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov6 && min6==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov7 && min7==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov8 && min8==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
            window.location.reload();
 	       }
 	    });
    }if(h==hov9 && min9==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov10 && min10==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov11 && min11==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov12 && min12==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov13 && min13==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov14 && min14==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov15 && min15==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov16 && min16==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov17 && min17==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov18 && min18==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov19 && min19==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov20 && min20==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov21 && min21==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov22 && min22==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }if(h==hov23 && min23==m && s==1){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 window.location.reload();
 	       }
 	    });
    }
}
    refresh();

  </script>

<?php /**PATH /Applications/MAMP/htdocs/newgame/resources/views/admin/dalyresult.blade.php ENDPATH**/ ?>