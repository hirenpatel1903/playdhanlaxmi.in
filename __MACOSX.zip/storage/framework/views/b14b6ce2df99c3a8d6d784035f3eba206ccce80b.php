<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
    .blinking {
	text-align:center;
    background: red;
	border-radius: 70px;
}

.blinking.blink {
	opacity:0;
}
</style>
	<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
          <!--breadcrumb-->
          <div class="md-col-12">
            <span class="dcoder"></span>
          </div>
					<div class="row">
                        <?php if($games->count()> 0): ?>
                         <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php
                           $sumamou = DB::table('dalygame')->where('game',$item->name)->sum('amount');
                            date_default_timezone_set("Asia/Calcutta");
                             $date = date_create($item->datetime);
                               $olddate = date_format($date,"Y-m-d h:i");
                               $newTime = date("Y-m-d H:i",strtotime(date("Y-m-d h:i:s")."-5 minutes"));
                          ?>
                             <?php if(strtotime($newTime) <= strtotime($olddate)): ?>
                                <div class="col-12 col-lg-3">
                                    <div class="card radius-15">
                                        <div class="card-body">
                                            <div class="d-flex align-items-center">
                                                <div>
                                                    <h2 class="mb-0 text-white">Amount:<span><?= $sumamou ?? '' ?> </span></h2>
                                                </div>
                                            </div>
                                            <div class="d-flex align-items-center">
                                                <div>
                                                    <p class="mb-0 text-white">name: <?= strtoupper($item->name ?? '') ?></p>
                                                    <p class="mb-0 text-white">Date: <?= strtoupper($item->dates ?? '') ?></p>
                                                    <p class="mb-0 text-white">Time: <?= strtoupper($item->times ?? '') ?> </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php
                           $datetimes = DB::table('datetime')->get();
                        ?>
                        <?php $__currentLoopData = $datetimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <?php
                         $selectedTime = date('h:i:s', strtotime($itemss->datetime));
                         $i = date('i', strtotime($itemss->datetime));
                         $starttime = strtotime("-5 minutes", strtotime($selectedTime));
                         $starttimes = date('i', $starttime);
                         $hover = date('h', $starttime);
                         $mints = date('i', $starttime);
                         $endtimes = date("i");
                         //echo "starttime".$starttimes."<br>"."enddate".$endtimes;
                         ?>
                         <?php if($hover== $starttimes>= $endtimes): ?>
                          <?php if($starttimes==$endtimes || $starttimes <= $endtimes): ?>
                            <div class="col-12 col-lg-3">
                                    <div class="card radius-15">
                                        <div class="card-body">
                                            <div class="d-flex align-items-center">
                                                <div>
                                                    <p class="mb-0 text-white">Date time: <?= date('Y-M-d h:i:A', strtotime($itemss->datetime)); ?></p>
                                                </div>
                                            </div>
                                            <div class="d-flex align-items-center">
                                                <div>
                                            <?php if($starttimes==$endtimes): ?>
                                                    <?php
                                                    if(empty(Session::get('number'))) {
                                                      $gamess = DB::table('games')->inRandomOrder()->first();
                                                        $digits = 2;
                                                        $numbers = rand(pow(10, $digits-1), pow(10, $digits)-1);
                                                        Session::put('number',$gamess->name.$numbers);
                                                    }
                                                    ?>
                                                    <p class="mb-0 text-white blinking">Open this number:<?php echo e(Session::get('number')); ?></p>
                                                    <p class="mb-0 text-white"><button class="btm btn-success btn-sm" data-toggle="modal" data-target="#myModal">Edit</button></p>
                                            <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<!--end breadcrumb-->
				</div>
			</div>
			<!--end page-content-wrapper-->
        </div>

		<?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>


<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
        <form action="<?php echo e(url('admin/changenumber')); ?>" method="Post">
            <?php echo csrf_field(); ?>
            <div class="form-group" >
                <select class="form-control" name="game" required>
                <option value="">Select Option</option>

                    <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($gameitem->name ?? ''); ?>"><?php echo e($gameitem->name ?? ''); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
           <div class="form-group">
               <input type="text" class="form-control" name="number">
           </div>

           <input type="submit" name="submit" value="Submit" class="btn btn-success">
        </form>
        </div>
      </div>
    </div>
  </div>

  <script>
var addnumber = "<?php echo e(url('admin/addnumber')); ?>";
$(function() {
	var $blinkText = $(".blinking");
	setInterval(function() {
		$blinkText.toggleClass("blink");
	}, 1000);
});
var h2 = "<?php echo e($hover ?? ''); ?>";
var i = "<?php echo e($mints ?? ''); ?>";
var i1 = "<?php echo e($i ?? ''); ?>";
 var onemint = Number(i)+ Number(1);
//  alert(i1);
// alert(h2);
function refresh(){
    var now = new Date();
    var h = now.getHours() % 12 || 12;;
    var m = now.getMinutes();
    var s = now.getSeconds();
    var out = h+" : "+m+" : "+s;
    var trig = setTimeout(refresh,500);

    document.getElementsByClassName("dcoder")[0].innerHTML = out;
    if(h==h2 && m==i && s==2){
      location.reload();
    }
    else if(h==h2 && m==onemint && s==2){
        location.reload();
    }else if(h==h2 && m==i1 && s==2){
        $.ajax({
 	       type:'get',
 	       url:addnumber,
 	       success: function (data) {
                 alert(data);
 	       }
 	    });
    }
    }
    refresh();
  </script>

<?php /**PATH /Applications/MAMP/htdocs/sattaking/resources/views/admin/dalyresult.blade.php ENDPATH**/ ?>