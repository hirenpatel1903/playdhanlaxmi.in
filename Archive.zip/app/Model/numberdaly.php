<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class numberdaly extends Model
{
    protected $table = 'numberdaly';
}
