<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
		<!--End Back To Top Button-->
		<!--footer -->
		<div class="footer">
			<p class="mb-0">Syntrans @2021 | Developed By : <a href="" target="_blank">playdhanlaxmi</a>
			</p>
		</div>
		<!-- end footer -->
	</div>


	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="{{ asset('public/admin/') }}/assets/js/jquery.min.js"></script>
	<script src="{{ asset('public/admin/') }}/assets/js/popper.min.js"></script>
	<script src="{{ asset('public/admin/') }}/assets/js/bootstrap.min.js"></script>
	<!--plugins-->
	<script src="{{ asset('public/admin/') }}/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="{{ asset('public/admin/') }}/assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<!-- Vector map JavaScript -->
	<script src="{{ asset('public/admin/') }}/assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
	<script src="{{ asset('public/admin/') }}/assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
	<script src="{{ asset('public/admin/') }}/assets/plugins/vectormap/jquery-jvectormap-in-mill.js"></script>
	<script src="{{ asset('public/admin/') }}/assets/plugins/vectormap/jquery-jvectormap-us-aea-en.js"></script>
	<script src="{{ asset('public/admin/') }}/assets/plugins/vectormap/jquery-jvectormap-uk-mill-en.js"></script>
	<script src="{{ asset('public/admin/') }}/assets/plugins/vectormap/jquery-jvectormap-au-mill.js"></script>
	<script src="{{ asset('public/admin/') }}/assets/plugins/apexcharts-bundle/js/apexcharts.min.js"></script>
	<script src="{{ asset('public/admin/') }}/assets/js/index2.js"></script>
	<!-- App JS -->
	<script src="{{ asset('public/admin/') }}/assets/js/app.js"></script>
</body>
</html>
